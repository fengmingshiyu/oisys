package cn.njcit.mapper;

import cn.njcit.entity.AttendsList;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 * 考勤打卡 Mapper 接口
 * </p>
 *
 * @author njcit
 * @since 2024-09-03
 */
public interface AttendsListMapper extends BaseMapper<AttendsList> {

}
