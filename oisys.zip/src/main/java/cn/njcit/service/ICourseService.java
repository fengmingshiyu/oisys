package cn.njcit.service;

import cn.njcit.entity.Course;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程信息 服务类
 * </p>
 *
 * @author njcit
 * @since 2024-09-03
 */
public interface ICourseService extends IService<Course> {

}
