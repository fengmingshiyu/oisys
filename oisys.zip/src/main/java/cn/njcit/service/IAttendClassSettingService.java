package cn.njcit.service;

import cn.njcit.entity.AttendClassSetting;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程时间设置 服务类
 * </p>
 *
 * @author njcit
 * @since 2024-09-03
 */
public interface IAttendClassSettingService extends IService<AttendClassSetting> {

}
