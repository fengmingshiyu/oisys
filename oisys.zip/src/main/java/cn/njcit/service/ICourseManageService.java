package cn.njcit.service;

import cn.njcit.entity.CourseManage;
import com.baomidou.mybatisplus.extension.service.IService;

/**
 * <p>
 * 课程管理表 服务类
 * </p>
 *
 * @author njcit
 * @since 2024-09-03
 */
public interface ICourseManageService extends IService<CourseManage> {

}
