package cn.njcit.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.stereotype.Controller;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author njcit
 * @since 2024-09-03
 */
@Controller
@RequestMapping("/user")
public class UserController {

}
